# E5 Base — v1.0
- Params: ~110M
- Task: Embeddings
- Latency p95 (local CPU): ~100ms
- Notes: Use as dense retriever. No quantization in MVP.
