//! auto-generated from notebook
//! holds the latest notebook-produced gateway config
use serde::{Deserialize, Serialize};
pub const GATEWAY_CONFIG_JSON: &str = r#"{"ts": 1761845885, "version": "1.0.0", "note": "auto-generated from notebook (cooldowns + sync + grafana + schema)", "rbac": {"ts": 1761844959, "schema": "rbac/1", "roles": {"admin": ["chaos.set", "chaos.ns.set", "rl.update", "rl.promote", "rl.rollback", "drift.remediate", "ops.write"], "ml": ["rl.update", "rl.promote", "rl.rollback"], "sre": ["chaos.set", "chaos.ns.set", "drift.remediate", "ops.write"], "read-only": ["metrics.read", "runs.read", "ns.smoke"]}, "tokens": {"real-prod-token-123": "admin", "ml-team-token-456": "ml"}, "actions": {"chaos.set": "Set global chaos flags", "chaos.ns.set": "Set per-namespace chaos flags", "rl.update": "Update router/RL weights", "rl.promote": "Promote RL weights live", "rl.rollback": "Rollback RL weights", "drift.remediate": "Apply desired state to live gateway", "ops.write": "Regenerate ops / oncall docs", "metrics.read": "Read /metrics, prom, telemetry", "runs.read": "Read gateway_runs_agg + smoke", "ns.smoke": "Hit /answer with x-namespace for smoke tests"}}, "tenants": {"ts": 1761844959, "schema": "tenants/1", "tenants": {"default": {"chaos": {"disable_ce": false, "force_bm25": false, "verifier_v2": false}, "rl_weights": {"factual": 1.0, "sql": 1.0}}, "tenant-acme": {"chaos": {"disable_ce": true, "force_bm25": false}, "rl_weights": {"factual": 0.7, "sql": 1.2}}, "tenant-beta": {"chaos": {"disable_ce": false, "force_bm25": true}, "rl_weights": {"factual": 1.0, "sql": 1.0}}, "ratelimits": {"qps": 20, "burst": 40}}}, "desired_state": {"ts": 1761843687, "chaos": {"disable_ce": false, "force_bm25": false, "verifier_v2": false}, "rl_weights": {"factual": 1.0, "sql": 1.0}, "namespaces": ["default", "tenant-acme"]}, "schema_report": {}, "grafana_dashboard": {"annotations": {"list": []}, "editable": true, "gnetId": null, "graphTooltip": 0, "id": null, "links": [], "panels": [{"type": "timeseries", "title": "Gateway latency p95 (ms)", "datasource": {"type": "prometheus", "uid": "Prometheus"}, "targets": [{"expr": "histogram_quantile(0.95, sum(rate(gateway_answer_latency_ms_bucket[5m])) by (le))", "legendFormat": "p95", "refId": "A"}], "gridPos": {"h": 9, "w": 12, "x": 0, "y": 0}}, {"type": "timeseries", "title": "Fanout errors by step", "datasource": {"type": "prometheus", "uid": "Prometheus"}, "targets": [{"expr": "sum(rate(gateway_fanout_errors_total[5m])) by (step)", "legendFormat": "{{step}}", "refId": "A"}], "gridPos": {"h": 9, "w": 12, "x": 12, "y": 0}}, {"type": "timeseries", "title": "Strategy mix", "datasource": {"type": "prometheus", "uid": "Prometheus"}, "targets": [{"expr": "sum(rate(gateway_strategy_selected_total[5m])) by (strategy)", "legendFormat": "{{strategy}}", "refId": "A"}], "gridPos": {"h": 8, "w": 24, "x": 0, "y": 9}}], "refresh": "30s", "schemaVersion": 36, "style": "dark", "tags": ["rag", "gateway"], "templating": {"list": []}, "time": {"from": "now-1h", "to": "now"}, "timepicker": {}, "timezone": "", "title": "RAG Gateway", "uid": "rag-gateway", "version": 1}, "_meta": {"source": "notebook/gateway", "schema_version": "1.1.0", "written_at": 1761846562}, "ops_profile": "daily"}"#;
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GatewayConfig {
    #[serde(default)]
    pub ts: Option<u64>,
    #[serde(default)]
    pub version: Option<String>,
    #[serde(default)]
    pub note: Option<String>,
    #[serde(default)]
    pub rbac: serde_json::Value,
    #[serde(default)]
    pub tenants: serde_json::Value,
    #[serde(default)]
    pub desired_state: serde_json::Value,
    #[serde(default)]
    pub schema_report: serde_json::Value,
    #[serde(default)]
    pub grafana_dashboard: serde_json::Value,
}

impl GatewayConfig {
    pub fn from_embedded() -> serde_json::Result<Self> {
        serde_json::from_str(GATEWAY_CONFIG_JSON)
    }
}
