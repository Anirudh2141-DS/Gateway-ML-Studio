# Gateway Report
_generated: 2025-10-30 00:15:43_

## Latest run
- p95: **None ms**
- chaos: `{"disable_ce": false, "force_bm25": false, "verifier_v2": true}`
- base: `http://127.0.0.1:9910`

## Recent history
| when | p95 (ms) | chaos | file |
|------|----------|--------|------|
| 2025-10-29 23:59:43 | None | verifier_v2 | gateway_smoke_20251030-000220.json |