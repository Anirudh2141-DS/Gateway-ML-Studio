# MNLI (RoBERTa) — v1.0
- Task: NLI (Verifier v2 blend)
- Latency p95: ~250ms
- Use: Honor `X-Verify-V2=1`, blend with base faithfulness.
