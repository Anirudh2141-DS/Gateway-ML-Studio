# BGE Cross-Encoder — v1.0
- Params: ~300M
- Task: Rerank
- Latency p95: ~400ms
- Cost: Per-doc rerank charged in gateway meta.
