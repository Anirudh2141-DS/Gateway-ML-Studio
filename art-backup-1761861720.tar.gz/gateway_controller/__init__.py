# auto-generated
CONTROLLER_VERSION = "0.2.0-notebook"
CURRENT_SCHEMA = "1.1.0"
MIN_SUPPORTED_SCHEMA = "1.0.0"
ART_DIR = r"\tmp\art"
